package test;

import dev.edu.javaee.spring.factory.BeanFactory;
import dev.edu.javaee.spring.factory.Scanning;
import dev.edu.javaee.spring.factory.XMLBeanFactory;
import dev.edu.javaee.spring.resource.LocalFileResource;

public class test {

    public static void main(String[] args) throws NoSuchFieldException, SecurityException {
        LocalFileResource resource = new LocalFileResource("bean.xml");

        //Scanning.set(packagename);
        BeanFactory beanFactory = new XMLBeanFactory(resource,"test");
        boss boss = (boss) beanFactory.getBean("boss");
        System.out.println(boss.tostring());
    }
}