package test;

import annotation.Autowired;

public class boss {
@Autowired
  private office office;
@Autowired
  private car car;

  public String tostring(){
	  return "this boss has "+car.tostring()+" and in "+office.tostring();
  }
}