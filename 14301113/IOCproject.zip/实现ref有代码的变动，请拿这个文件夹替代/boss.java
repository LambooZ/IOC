package test;

import annotation.Autowired;

public class boss {
	private office office;
	public void setOffice(office office){
		this.office = office;
		
	}
  public String tostring(){
	  return "this boss has "+" and in "+office.tostring();
  }
}